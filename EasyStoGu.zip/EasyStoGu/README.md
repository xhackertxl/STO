EasyStoGu
====
Easy to use analyze StoGu
