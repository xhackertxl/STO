package org.easystogu.utils;

public enum CrossType {
	UNKNOWN, GORDON, DEAD, NEAR_GORDON, NEAR_DEAD
}
