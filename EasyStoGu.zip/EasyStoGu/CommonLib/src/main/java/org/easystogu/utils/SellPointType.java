package org.easystogu.utils;

public enum SellPointType {
	KDJ_Dead, MACD_Dead, ShenXian_Dead, Next_Day
}
