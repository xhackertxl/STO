package org.easystogu.multirunner;

public class TaskInfo {
    public String taskName;
    public long startTime;
    public long stopTime;
    public boolean completed = false;
}
