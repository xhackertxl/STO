package org.easystogu.runner;

import org.easystogu.db.access.ZiJinLiuTableHelper;

public class GenerateDataForGitHubRunner {
	private ZiJinLiuTableHelper zijinliuTableHelper = ZiJinLiuTableHelper.getInstance();

	private void generateZiJinLiuData() {

	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		GenerateDataForGitHubRunner runner = new GenerateDataForGitHubRunner();
	}

}
